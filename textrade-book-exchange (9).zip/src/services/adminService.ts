
// Re-export all admin services from the new modular structure
export * from './admin/adminQueries';
export * from './admin/adminMutations';
