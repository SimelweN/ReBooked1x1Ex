
export const categories = [
  { id: 'fiction', name: 'Fiction' },
  { id: 'non-fiction', name: 'Non-Fiction' },
  { id: 'textbook', name: 'Textbook' },
  { id: 'science', name: 'Science' },
  { id: 'mathematics', name: 'Mathematics' },
  { id: 'history', name: 'History' },
  { id: 'literature', name: 'Literature' },
  { id: 'biography', name: 'Biography' },
  { id: 'children', name: 'Children\'s Books' },
  { id: 'other', name: 'Other' },
];
